"""Analytics endpoints"""

from fastapi import APIRouter
from app.core.semantic_simulator import SemanticSimulator
from app.core.learning import learning
from datetime import datetime

router = APIRouter()

@router.get("/analytics/summary")
async def get_analytics_summary():
    """Get summary analytics"""
    simulator = SemanticSimulator()
    stats = simulator.get_stats()
    
    return {
        "total_anchors": stats["total"],
        "categories": stats["categories"],
        "interception_rate": learning.get_interception_rate(),
        "total_interactions": learning.stats.get("total_interactions", 0),
        "interceptions": learning.stats.get("interceptions", 0),
        "top_anchors": learning.get_top_anchors(5),
        "timestamp": datetime.now().isoformat()
    }

@router.get("/analytics/top-anchors")
async def get_top_anchors(limit: int = 10):
    """Get most frequent anchors"""
    return {"top_anchors": learning.get_top_anchors(limit)}

@router.get("/analytics/health")
async def analytics_health():
    """Analytics health check"""
    return {"status": "analytics_ready", "learning_enabled": True}
