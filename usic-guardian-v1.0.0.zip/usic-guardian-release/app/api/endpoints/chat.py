"""Chat endpoints with guardian protection"""

from fastapi import APIRouter, HTTPException
import time
import uuid
from app.models.request import ChatRequest
from app.models.response import ChatResponse
from app.services.guardian import GuardianService
from app.utils.logger import log

router = APIRouter()
guardian = GuardianService()

@router.post("/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    """
    Process a chat message through the guardian layer
    
    - Detects semantic collapse risk using scenario interpolation
    - Intercepts and modulates if needed
    - Returns protected response
    """
    start_time = time.time()
    
    try:
        # Generate request ID if not present
        if not hasattr(request, 'request_id') or not request.request_id:
            request.request_id = str(uuid.uuid4())
        
        result = await guardian.process(request)
        
        return ChatResponse(
            request_id=request.request_id,
            final_response=result["final_response"],
            intercepted=result["intercepted"],
            intercept_reason=result.get("intercept_reason"),
            protocol_used=result.get("protocol_used"),
            processing_time_ms=result.get("processing_time_ms", int((time.time() - start_time) * 1000)),
            semantic_score=result["semantic_score"],
            receptivity_score=result["receptivity_score"],
            collapse_risk=result["collapse_risk"],
            trajectory=result.get("trajectory"),
            silence_ms=result.get("silence_ms")
        )
        
    except Exception as e:
        log.error(f"Chat processing failed: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))
