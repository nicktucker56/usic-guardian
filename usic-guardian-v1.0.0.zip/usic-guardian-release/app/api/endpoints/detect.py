"""Detection-only endpoints"""

from fastapi import APIRouter, Query
from app.core.semantic_simulator import SemanticSimulator

router = APIRouter()
simulator = SemanticSimulator()

@router.post("/detect")
async def detect(utterance: str = Query(..., description="The utterance to analyze")):
    """
    Run detection only - no response generation
    """
    result = simulator.analyze(utterance)
    
    return {
        "collapse_risk": result.get("collapse_risk", 0),
        "receptivity_score": result.get("receptivity", 0),
        "semantic_score": result.get("semantic_score", 0),
        "primary_risk": result.get("primary_risk", "none"),
        "status": result.get("status", "stable"),
        "trajectory": result.get("trajectory", "stable"),
        "anchor_id": result.get("anchor_id", "default"),
        "confidence": result.get("confidence", 0)
    }
