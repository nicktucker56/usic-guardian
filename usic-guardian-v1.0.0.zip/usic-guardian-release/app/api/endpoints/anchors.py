"""Anchor management endpoints - Real implementation"""

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from typing import List, Optional
from app.core.semantic_simulator import SemanticSimulator
from app.core.anchor_manager import SemanticAnchor

router = APIRouter()

# Initialize simulator once
_simulator = None

def get_simulator():
    global _simulator
    if _simulator is None:
        _simulator = SemanticSimulator()
    return _simulator

class AnchorCreate(BaseModel):
    id: str
    name: str
    keywords: List[str]
    receptivity: float
    collapse: float
    responses: List[str]
    category: str
    subcategory: str
    intensity: float

@router.get("/anchors/stats")
async def anchor_stats():
    """Get real anchor statistics"""
    simulator = get_simulator()
    stats = simulator.get_stats()
    return stats

@router.get("/anchors")
async def list_anchors(category: Optional[str] = Query(None, description="Filter by category")):
    """List all anchors, optionally filtered by category"""
    simulator = get_simulator()
    anchors = simulator.manager.get_all_anchors()
    
    result = []
    for anchor in anchors.values():
        if category and anchor.category != category:
            continue
        result.append({
            "id": anchor.id,
            "name": anchor.name,
            "category": anchor.category,
            "subcategory": anchor.subcategory,
            "receptivity": anchor.receptivity,
            "collapse": anchor.collapse,
            "responses": anchor.responses,
            "intensity": anchor.intensity
        })
    
    return {
        "total": len(result),
        "anchors": result
    }

@router.post("/anchors")
async def create_anchor(anchor: AnchorCreate):
    """Create a new anchor"""
    simulator = get_simulator()
    existing = simulator.manager.get_anchor(anchor.id)
    if existing:
        raise HTTPException(status_code=400, detail="Anchor ID already exists")
    
    new_anchor = SemanticAnchor(
        id=anchor.id,
        name=anchor.name,
        keywords=anchor.keywords,
        receptivity=anchor.receptivity,
        collapse=anchor.collapse,
        responses=anchor.responses,
        category=anchor.category,
        subcategory=anchor.subcategory,
        intensity=anchor.intensity
    )
    simulator.manager.add_anchor(new_anchor)
    return {"status": "created", "id": anchor.id}
