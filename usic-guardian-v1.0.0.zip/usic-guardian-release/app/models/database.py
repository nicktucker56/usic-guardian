"""Database models for USIC Guardian - Optional, will be used when DB is configured"""

from app.utils.config import settings
from app.utils.logger import log

# Only initialize database if URL is provided
if settings.database_url:
    try:
        from sqlalchemy import create_engine, Column, Integer, String, Float, Boolean, DateTime, Text, ForeignKey
        from sqlalchemy.ext.declarative import declarative_base
        from sqlalchemy.orm import relationship, sessionmaker
        from datetime import datetime
        
        Base = declarative_base()
        
        class Session(Base):
            __tablename__ = 'sessions'
            
            id = Column(Integer, primary_key=True)
            session_id = Column(String(100), unique=True, nullable=False)
            created_at = Column(DateTime, default=datetime.now)
            last_active = Column(DateTime, default=datetime.now, onupdate=datetime.now)
            
            interactions = relationship("Interaction", back_populates="session")
        
        class Interaction(Base):
            __tablename__ = 'interactions'
            
            id = Column(Integer, primary_key=True)
            session_id = Column(String(100), ForeignKey('sessions.session_id'))
            utterance = Column(Text, nullable=False)
            response = Column(Text, nullable=False)
            intercepted = Column(Boolean, default=False)
            intercept_reason = Column(String(50))
            protocol_used = Column(String(50))
            collapse_risk = Column(Float)
            receptivity_score = Column(Float)
            created_at = Column(DateTime, default=datetime.now)
            
            session = relationship("Session", back_populates="interactions")
        
        engine = create_engine(settings.database_url)
        SessionLocal = sessionmaker(bind=engine)
        
        def init_db():
            Base.metadata.create_all(engine)
            log.info("✅ Database initialized")
        
        log.info("Database module loaded")
        
    except Exception as e:
        log.warning(f"Database initialization failed: {e}")
        log.warning("Running without database support")
        SessionLocal = None
        init_db = lambda: None
else:
    log.info("No database URL configured. Running without database.")
    SessionLocal = None
    init_db = lambda: None
