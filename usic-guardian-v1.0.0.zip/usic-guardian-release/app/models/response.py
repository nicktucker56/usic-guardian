"""Response models for USIC API"""

from pydantic import BaseModel
from typing import Optional, List

class ChatResponse(BaseModel):
    """Chat response from guardian"""
    request_id: Optional[str] = None
    final_response: str
    intercepted: bool
    intercept_reason: Optional[str] = None
    protocol_used: Optional[str] = None
    processing_time_ms: int
    semantic_score: float
    receptivity_score: float
    collapse_risk: float
    trajectory: Optional[str] = None
    silence_ms: Optional[int] = None

class DetectResponse(BaseModel):
    """Detection-only response"""
    collapse_risk: float
    receptivity_score: float
    semantic_score: float
    primary_risk: str
    status: str
    trajectory: str
    confidence: float
