"""Request models for USIC API"""

from pydantic import BaseModel, Field
from typing import Optional, List
import uuid

class HumanContext(BaseModel):
    """Human context for semantic detection"""
    session_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: Optional[str] = None
    utterance_history: List[str] = []
    language: str = "en"
    domain: Optional[str] = None

class ChatRequest(BaseModel):
    """Chat request to guardian"""
    request_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    human_utterance: str
    human_context: HumanContext = Field(default_factory=HumanContext)
    intercept_threshold: float = 0.6
