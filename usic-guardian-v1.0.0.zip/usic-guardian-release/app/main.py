"""USIC Guardian Server - Main Application"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from contextlib import asynccontextmanager
import os

from app.api.endpoints import health, chat, detect
from app.api.endpoints.anchors import router as anchors_router
from app.utils.logger import setup_logging, log
from app.utils.config import settings

# Setup logging
setup_logging()

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Lifespan context manager"""
    log.info(f"🚀 USIC Guardian Server starting...")
    log.info(f"   Environment: {settings.environment}")
    log.info(f"   Intercept threshold: {settings.intercept_threshold}")
    yield
    log.info("👋 USIC Guardian Server shutting down...")

# Create app
app = FastAPI(
    title="USIC Guardian API",
    description="Semantic integrity layer for human-AI dialogue",
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/docs" if settings.environment == "development" else None,
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(health.router, tags=["Health"])
app.include_router(chat.router, prefix="/v1", tags=["Chat"])
app.include_router(detect.router, prefix="/v1", tags=["Detection"])
app.include_router(anchors_router, prefix="/v1", tags=["Anchors"])

# Mount static files
os.makedirs("static", exist_ok=True)
app.mount("/static", StaticFiles(directory="static"), name="static")

@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "name": "USIC Guardian Server",
        "version": "1.0.0",
        "status": "running",
        "docs": "/docs" if settings.environment == "development" else "unavailable"
    }
