"""Logging configuration"""

import sys
import os
from loguru import logger
from app.utils.config import settings

def setup_logging():
    """Configure loguru logging"""
    logger.remove()
    
    # Console handler
    logger.add(
        sys.stdout,
        format="<green>{time:HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan> - <level>{message}</level>",
        level=settings.log_level,
        colorize=True
    )
    
    # File handler
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    logger.add(
        f"{log_dir}/usic_{{time:YYYY-MM-DD}}.log",
        rotation="1 day",
        retention="30 days",
        format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {name} | {message}",
        level="INFO"
    )
    
    logger.info(f"Logging configured - Console: {settings.log_level}, File: logs/")
    return logger

# Export logger instance
log = logger
