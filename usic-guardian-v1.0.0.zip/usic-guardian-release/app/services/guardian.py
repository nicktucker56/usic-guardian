"""Guardian Engine - With enhanced response selection"""

import time
from typing import Dict, Any, List
from app.utils.logger import log
from app.core.semantic_simulator import SemanticSimulator
from app.core.ai_router import AIRouter
from app.core.emergency_detector import is_emergency, get_emergency_response
from app.core.response_selector import ResponseSelector
from app.models.request import ChatRequest

class GuardianService:
    """Guardian that intercepts risky messages with enhanced response selection"""
    
    def __init__(self):
        self.simulator = SemanticSimulator()
        self.ai_router = AIRouter()
        self.session_histories = {}
        self.response_selector = ResponseSelector()
        log.info(f"GuardianService initialized with enhanced response selector")
    
    async def process(self, request: ChatRequest) -> Dict[str, Any]:
        start_time = time.time()
        
        session_id = request.human_context.session_id
        utterance = request.human_utterance
        threshold = request.intercept_threshold
        
        # EMERGENCY OVERRIDE - highest priority
        if is_emergency(utterance):
            log.info(f"🚨 EMERGENCY DETECTED: {utterance[:100]}")
            soothing_response = self.response_selector.get_soothing_response(0.92, "emergency")
            return {
                "final_response": soothing_response,
                "intercepted": True,
                "intercept_reason": "emergency",
                "protocol_used": "witness",
                "semantic_score": 0.12,
                "receptivity_score": 0.20,
                "collapse_risk": 0.88,
                "trajectory": "collapsing",
                "source": "guardian_emergency",
                "processing_time_ms": int((time.time() - start_time) * 1000)
            }
        
        # Get history
        if session_id not in self.session_histories:
            self.session_histories[session_id] = []
        history = self.session_histories[session_id]
        
        # Analyze semantic state
        state = self.simulator.analyze(utterance, history)
        
        collapse_risk = state.get("collapse_risk", 0.25)
        anchor_id = state.get("anchor_id", "default")
        anchor_name = state.get("anchor_name", "")
        
        log.info(f"Risk: {collapse_risk:.2f}, Traj: {state.get('trajectory', 'stable')}, Anchor: {anchor_id}")
        
        # Intercept if collapse risk is HIGH
        if collapse_risk > threshold:
            # Use the response selector for a soothing response
            final_response = self.response_selector.get_soothing_response(collapse_risk, anchor_name)
            intercepted = True
            source = "guardian"
            
            # Determine protocol based on risk
            if collapse_risk > 0.7:
                protocol = "witness"
            elif collapse_risk > 0.5:
                protocol = "hospitality"
            else:
                protocol = "interval"
            
            intercept_reason = state.get("primary_risk", "high_risk")
            
            log.info(f"INTERCEPTED - Risk: {collapse_risk:.2f}, Protocol: {protocol}")
            
        else:
            # Pass through to AI
            final_response = await self.ai_router.generate(utterance, state, session_id)
            intercepted = False
            source = self.ai_router.active_model
            protocol = None
            intercept_reason = None
            
            log.info(f"PASSED THROUGH to {source}")
        
        # Update history
        self.session_histories[session_id].append(utterance)
        if len(self.session_histories[session_id]) > 20:
            self.session_histories[session_id].pop(0)
        
        return {
            "final_response": final_response,
            "intercepted": intercepted,
            "intercept_reason": intercept_reason,
            "protocol_used": protocol,
            "semantic_score": state.get("semantic_score", 0.75),
            "receptivity_score": state.get("receptivity", 0.7),
            "collapse_risk": collapse_risk,
            "trajectory": state.get("trajectory", "stable"),
            "source": source,
            "processing_time_ms": int((time.time() - start_time) * 1000)
        }
