"""Redis cache service for USIC Guardian"""

import json
import redis
from typing import Optional, Any
from app.utils.logger import log
from app.utils.config import settings

class CacheService:
    """Redis-based cache for detection results and sessions"""
    
    def __init__(self):
        self.client = redis.Redis.from_url(settings.redis_url, decode_responses=True)
        self.ttl = 3600  # 1 hour default
    
    def get(self, key: str) -> Optional[Any]:
        """Get value from cache"""
        try:
            value = self.client.get(key)
            if value:
                return json.loads(value)
        except Exception as e:
            log.error(f"Cache get error: {e}")
        return None
    
    def set(self, key: str, value: Any, ttl: int = None):
        """Set value in cache"""
        try:
            self.client.setex(
                key,
                ttl or self.ttl,
                json.dumps(value)
            )
        except Exception as e:
            log.error(f"Cache set error: {e}")
    
    def delete(self, key: str):
        """Delete from cache"""
        try:
            self.client.delete(key)
        except Exception as e:
            log.error(f"Cache delete error: {e}")
    
    def get_session(self, session_id: str) -> Optional[dict]:
        """Get session state from cache"""
        return self.get(f"session:{session_id}")
    
    def set_session(self, session_id: str, state: dict):
        """Set session state in cache"""
        self.set(f"session:{session_id}", state, ttl=3600)

# Singleton instance
cache = CacheService()
