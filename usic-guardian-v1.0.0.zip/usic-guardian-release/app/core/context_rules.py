"""Contextual Disambiguation Rules - Expanded version"""

from typing import Dict, List, Tuple, Optional

class ContextRules:
    """Expanded rules for disambiguating metaphorical vs literal meaning"""
    
    def __init__(self):
        # Expanded ambiguous words (now 30+ words)
        self.ambiguous_words = {
            "empty": {
                "metaphorical": [
                    "my life", "your life", "our life", "their life",
                    "feel", "feeling", "felt", "inside", "within",
                    "soul", "heart", "spirit", "mind",
                    "everything", "nothing", "point", "purpose", "meaning",
                    "i am", "i feel", "i'm", "i've been feeling",
                    "these days", "lately", "recently", "always", "never",
                    "inside me", "within me", "deep down"
                ],
                "literal": [
                    "bottle", "glass", "cup", "container", "box", "bag", "tank", "jug", "jar",
                    "fridge", "cabinet", "shelf", "pantry", "garage", "closet", "drawer",
                    "liters", "gallons", "ounces", "ml", "cups", "teaspoons",
                    "pour", "fill", "drink", "use", "need", "get",
                    "is the", "is this", "is that", "does the", "does this",
                    "gas tank", "fuel tank", "water tank"
                ]
            },
            "broken": {
                "metaphorical": [
                    "i am", "i feel", "i'm", "my heart", "my spirit", "my soul",
                    "relationship", "marriage", "friendship", "trust",
                    "inside", "within", "i can't", "i don't know",
                    "promise", "vow", "word", "faith",
                    "my will", "my spirit", "my hope"
                ],
                "literal": [
                    "phone", "computer", "machine", "car", "engine", "motor",
                    "glass", "window", "door", "lock", "handle",
                    "part", "piece", "component", "device",
                    "needs repair", "won't work", "not working",
                    "screen", "keyboard", "mouse", "cable"
                ]
            },
            "lost": {
                "metaphorical": [
                    "i am", "i feel", "i'm", "myself", "my way", "my path",
                    "in life", "in this world", "in this journey",
                    "direction", "purpose", "meaning", "sense of",
                    "confused", "don't know", "what to do",
                    "my identity", "who i am"
                ],
                "literal": [
                    "keys", "wallet", "phone", "glasses", "remote", "item", "object",
                    "my way (to)", "the address", "the location", "the place",
                    "in the city", "in the building", "on the map",
                    "can't find", "searching for", "looking for",
                    "my luggage", "my bag", "my package"
                ]
            },
            "stuck": {
                "metaphorical": [
                    "i am", "i feel", "i'm", "in life", "in this situation",
                    "can't move forward", "no progress", "dead end",
                    "relationship", "career", "job", "life",
                    "don't know what to do", "can't decide",
                    "in a rut", "going nowhere"
                ],
                "literal": [
                    "car", "truck", "vehicle", "traffic", "traffic jam",
                    "door", "window", "drawer", "zipper", "lock",
                    "in the mud", "in the snow", "in traffic",
                    "won't move", "can't move",
                    "elevator", "escalator"
                ]
            },
            "heavy": {
                "metaphorical": [
                    "my heart", "my mind", "my soul", "my spirit",
                    "the weight", "this feeling", "this burden",
                    "i feel", "it feels", "this is", "this is too much",
                    "emotion", "thoughts", "responsibility",
                    "on my shoulders", "on my mind"
                ],
                "literal": [
                    "box", "package", "bag", "object", "thing",
                    "weights", "equipment", "furniture",
                    "to lift", "to carry", "to move",
                    "rain", "clouds", "sky"
                ]
            },
            "light": {
                "metaphorical": [
                    "my heart", "my mind", "my soul", "my spirit",
                    "i feel", "it feels", "this feeling",
                    "burden lifted", "weight off", "free",
                    "hope", "relief", "peace"
                ],
                "literal": [
                    "bulb", "lamp", "switch", "room", "house",
                    "feather", "object", "package",
                    "turn on", "turn off", "flick",
                    "sun", "moon", "stars"
                ]
            },
            "dark": {
                "metaphorical": [
                    "my mind", "my thoughts", "my soul", "my spirit",
                    "place", "time", "period", "days",
                    "feeling", "mood", "emotion",
                    "depression", "despair", "hopeless",
                    "dark place", "dark time"
                ],
                "literal": [
                    "room", "house", "street", "outside", "night",
                    "no light", "lights off", "can't see",
                    "alley", "hallway", "basement"
                ]
            },
            "cold": {
                "metaphorical": [
                    "my heart", "my soul", "my spirit",
                    "feeling", "emotion", "welcome", "reception",
                    "distant", "detached", "unfeeling",
                    "cold shoulder", "cold heart"
                ],
                "literal": [
                    "weather", "room", "house", "outside",
                    "temperature", "freezing", "chilly",
                    "hands", "feet", "body",
                    "drink", "food", "water"
                ]
            },
            "warm": {
                "metaphorical": [
                    "my heart", "my soul", "my spirit",
                    "feeling", "emotion", "welcome", "reception",
                    "loving", "caring", "kind",
                    "warm heart", "warm welcome"
                ],
                "literal": [
                    "weather", "room", "house", "outside",
                    "temperature", "hot", "heating",
                    "hands", "feet", "body",
                    "blanket", "clothes"
                ]
            },
            "high": {
                "metaphorical": [
                    "spirits", "hopes", "expectations",
                    "feeling", "mood", "energy",
                    "on top of the world", "flying high"
                ],
                "literal": [
                    "mountain", "building", "shelf", "ceiling",
                    "temperature", "price", "cost",
                    "altitude", "height"
                ]
            },
            "low": {
                "metaphorical": [
                    "spirits", "hopes", "energy",
                    "feeling", "mood", "point",
                    "rock bottom", "down"
                ],
                "literal": [
                    "ground", "floor", "shelf", "level",
                    "temperature", "price", "cost",
                    "battery", "fuel"
                ]
            },
            "deep": {
                "metaphorical": [
                    "feelings", "emotions", "thoughts",
                    "connection", "love", "understanding",
                    "inside me", "within me"
                ],
                "literal": [
                    "water", "ocean", "pool", "hole",
                    "cut", "wound", "breath"
                ]
            },
            "shallow": {
                "metaphorical": [
                    "feelings", "emotions", "understanding",
                    "relationship", "connection"
                ],
                "literal": [
                    "water", "pool", "end", "container"
                ]
            },
            "hard": {
                "metaphorical": [
                    "life", "time", "situation",
                    "to handle", "to deal with", "to bear",
                    "difficult", "challenging"
                ],
                "literal": [
                    "rock", "stone", "surface", "ground",
                    "material", "object"
                ]
            },
            "soft": {
                "metaphorical": [
                    "heart", "nature", "approach",
                    "gentle", "kind", "tender"
                ],
                "literal": [
                    "pillow", "fabric", "material", "surface"
                ]
            },
            "sharp": {
                "metaphorical": [
                    "pain", "words", "comment", "criticism",
                    "mind", "intelligence"
                ],
                "literal": [
                    "knife", "blade", "edge", "point",
                    "object", "tool"
                ]
            },
            "dull": {
                "metaphorical": [
                    "mind", "feeling", "sensation",
                    "boring", "uninteresting"
                ],
                "literal": [
                    "knife", "blade", "edge", "color"
                ]
            },
            "bright": {
                "metaphorical": [
                    "future", "prospects", "outlook",
                    "mind", "intelligence", "idea",
                    "smile", "personality"
                ],
                "literal": [
                    "light", "sun", "room", "color"
                ]
            },
            "clear": {
                "metaphorical": [
                    "mind", "thoughts", "understanding",
                    "path", "direction", "future"
                ],
                "literal": [
                    "sky", "water", "glass", "surface"
                ]
            },
            "cloudy": {
                "metaphorical": [
                    "mind", "thoughts", "judgment",
                    "future", "prospects"
                ],
                "literal": [
                    "sky", "weather", "water"
                ]
            }
        }
        
        # Expanded intensifiers
        self.metaphorical_intensifiers = [
            "so", "very", "really", "extremely", "completely", "totally",
            "just", "always", "never", "forever", "constantly",
            "inside", "within", "deep down", "in my soul",
            "utterly", "absolutely", "entirely", "wholly",
            "in my heart", "in my mind", "in my spirit"
        ]
    
    def analyze_word(self, word: str, utterance: str) -> Tuple[str, float]:
        """Analyze a specific ambiguous word in context"""
        if word not in self.ambiguous_words:
            return ("ambiguous", 0.5)
        
        utterance_lower = utterance.lower()
        rules = self.ambiguous_words[word]
        
        metaphorical_score = 0
        for marker in rules["metaphorical"]:
            if marker in utterance_lower:
                metaphorical_score += 1
        
        literal_score = 0
        for marker in rules["literal"]:
            if marker in utterance_lower:
                literal_score += 1
        
        for intensifier in self.metaphorical_intensifiers:
            if intensifier in utterance_lower:
                metaphorical_score += 0.5
        
        total = metaphorical_score + literal_score
        if total == 0:
            return ("ambiguous", 0.5)
        
        metaphorical_weight = metaphorical_score / total
        literal_weight = literal_score / total
        
        if metaphorical_weight > 0.6:
            return ("metaphorical", metaphorical_weight)
        elif literal_weight > 0.6:
            return ("literal", literal_weight)
        else:
            return ("ambiguous", max(metaphorical_weight, literal_weight))
    
    def get_adjustment(self, word: str, interpretation: str, confidence: float) -> Dict:
        """Get risk adjustment based on interpretation"""
        if interpretation == "literal":
            return {
                "receptivity_adjustment": +0.15,
                "collapse_adjustment": -0.20,
                "explanation": f"Literal use of '{word}' detected - reducing risk"
            }
        elif interpretation == "metaphorical":
            return {
                "receptivity_adjustment": -0.10,
                "collapse_adjustment": +0.15,
                "explanation": f"Metaphorical use of '{word}' detected - increasing risk"
            }
        else:
            return {
                "receptivity_adjustment": 0,
                "collapse_adjustment": 0,
                "explanation": f"Ambiguous use of '{word}' - no adjustment"
            }
    
    def analyze_utterance(self, utterance: str) -> Dict:
        """Analyze entire utterance for ambiguous words"""
        utterance_lower = utterance.lower()
        results = {}
        
        for word in self.ambiguous_words.keys():
            if word in utterance_lower.split():
                interpretation, confidence = self.analyze_word(word, utterance)
                results[word] = {
                    "interpretation": interpretation,
                    "confidence": confidence,
                    "adjustment": self.get_adjustment(word, interpretation, confidence)
                }
        
        total_receptivity_adj = 0
        total_collapse_adj = 0
        explanations = []
        
        for word, data in results.items():
            total_receptivity_adj += data["adjustment"]["receptivity_adjustment"]
            total_collapse_adj += data["adjustment"]["collapse_adjustment"]
            explanations.append(data["adjustment"]["explanation"])
        
        total_receptivity_adj = max(-0.3, min(0.3, total_receptivity_adj))
        total_collapse_adj = max(-0.3, min(0.3, total_collapse_adj))
        
        return {
            "words_analyzed": list(results.keys()),
            "receptivity_adjustment": total_receptivity_adj,
            "collapse_adjustment": total_collapse_adj,
            "explanations": explanations,
            "details": results
        }
