"""Learning system - Tracks anchor usage"""

import json
import os
from datetime import datetime
from typing import Dict, List, Tuple
from app.utils.logger import log

class LearningSystem:
    """Track anchor usage and adapt"""
    
    def __init__(self, data_file="data/learning.json"):
        self.data_file = data_file
        self.stats = self._load()
    
    def _load(self) -> Dict:
        """Load learning data"""
        os.makedirs(os.path.dirname(self.data_file), exist_ok=True)
        if os.path.exists(self.data_file):
            try:
                with open(self.data_file, 'r') as f:
                    return json.load(f)
            except:
                return self._init_stats()
        return self._init_stats()
    
    def _init_stats(self) -> Dict:
        """Initialize statistics"""
        return {
            "anchor_counts": {},
            "total_interactions": 0,
            "interceptions": 0,
            "last_reset": datetime.now().isoformat()
        }
    
    def record_interaction(self, anchor_id: str, intercepted: bool, protocol: str = None):
        """Record an interaction"""
        if anchor_id not in self.stats["anchor_counts"]:
            self.stats["anchor_counts"][anchor_id] = 0
        self.stats["anchor_counts"][anchor_id] += 1
        self.stats["total_interactions"] += 1
        if intercepted:
            self.stats["interceptions"] += 1
        self._save()
    
    def get_top_anchors(self, limit: int = 10) -> List[Tuple[str, int]]:
        """Get most frequent anchors"""
        sorted_anchors = sorted(self.stats["anchor_counts"].items(), key=lambda x: x[1], reverse=True)
        return sorted_anchors[:limit]
    
    def get_interception_rate(self) -> float:
        """Get overall interception rate"""
        if self.stats["total_interactions"] == 0:
            return 0.0
        return self.stats["interceptions"] / self.stats["total_interactions"]
    
    def _save(self):
        """Save learning data"""
        with open(self.data_file, 'w') as f:
            json.dump(self.stats, f, indent=2)

# Global instance
learning = LearningSystem()
