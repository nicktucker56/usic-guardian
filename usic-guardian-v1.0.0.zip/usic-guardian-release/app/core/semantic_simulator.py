"""Semantic Simulator - With Context Rules"""

import random
from typing import Dict, List, Optional
from app.utils.logger import log
from app.core.anchor_manager import AnchorManager
from app.core.context_rules import ContextRules

class SemanticSimulator:
    """Semantic simulator with contextual disambiguation rules"""
    
    def __init__(self):
        self.manager = AnchorManager()
        self.context_rules = ContextRules()
        self.fallback_responses = {
            "stable": [
                "I think I understand what you're saying. How can I help?",
                "Let me make sure I've got this right. What would be most helpful for you right now?",
                "I'm following. What do you need from me?"
            ],
            "fragmenting": [
                "This sounds important. Let's focus on what matters most. How can I support you?",
                "I hear this is weighing on you. What would be helpful to talk through?",
                "Let's sit with this for a moment. What's the one thing you need right now?"
            ],
            "collapsing": [
                "I'm here with you. You don't have to carry this alone. What do you need?",
                "That's a lot to hold. How can I help lighten the load?",
                "I'm listening. What would be most helpful right now?"
            ]
        }
        log.info(f"SemanticSimulator initialized with {self.manager.get_stats()['total']} anchors")
    
    def analyze(self, utterance: str, history: List[str] = None) -> Dict:
        """Analyze utterance with context rules"""
        # First, run context rules on ambiguous words
        context_analysis = self.context_rules.analyze_utterance(utterance)
        log.debug(f"Context analysis: {context_analysis['words_analyzed']}")
        
        # Find matching anchor
        anchor, confidence = self.manager.find_best_match(utterance)
        
        if anchor:
            c = anchor.collapse
            r = anchor.receptivity
            anchor_id = anchor.id
            anchor_name = anchor.name
            category = anchor.category
        else:
            c = 0.25
            r = 0.70
            anchor_id = "default"
            anchor_name = "general"
            category = "general"
            confidence = 0
        
        # Apply context adjustments
        c = c + context_analysis["collapse_adjustment"]
        r = r + context_analysis["receptivity_adjustment"]
        
        # Clamp values
        c = max(0.0, min(1.0, c))
        r = max(0.0, min(1.0, r))
        
        trajectory = "collapsing" if c > 0.65 else "fragmenting" if c > 0.45 else "stable"
        
        return {
            "receptivity": r,
            "collapse_risk": c,
            "semantic_score": 1 - c,
            "trajectory": trajectory,
            "anchor_id": anchor_id,
            "anchor_name": anchor_name,
            "category": category,
            "confidence": confidence,
            "status": "critical" if c > 0.6 else "monitoring" if c > 0.3 else "stable",
            "context_analysis": context_analysis
        }
    
    def generate_response(self, state: Dict, utterance: str, history: List[str] = None) -> Dict:
        """Generate guardian response"""
        collapse = state.get("collapse_risk", 0.25)
        trajectory = state.get("trajectory", "stable")
        anchor_id = state.get("anchor_id", "default")
        context = state.get("context_analysis", {})
        
        # Check if this is a literal statement (should not intercept)
        is_literal = False
        for word_data in context.get("details", {}).values():
            if word_data.get("interpretation") == "literal" and word_data.get("confidence", 0) > 0.7:
                is_literal = True
                break
        
        # For literal statements, always pass through
        if is_literal and collapse < 0.6:
            return {
                "text": self._simulate_base_response(utterance),
                "type": "response",
                "intercepted": False,
                "protocol": None
            }
        
        # No interception needed for low risk
        if collapse < 0.4:
            return {
                "text": self._simulate_base_response(utterance),
                "type": "response",
                "intercepted": False,
                "protocol": None
            }
        
        # Select protocol
        if collapse > 0.7:
            protocol = "witness"
        elif collapse > 0.5:
            protocol = "hospitality"
        else:
            protocol = "interval"
        
        # Try anchor response
        anchor = self.manager.get_anchor(anchor_id)
        if anchor and anchor.responses and collapse > 0.4:
            return {
                "text": random.choice(anchor.responses),
                "type": "response",
                "intercepted": True,
                "protocol": protocol
            }
        
        # Fallback
        fallback = self.fallback_responses.get(trajectory, self.fallback_responses["stable"])
        return {
            "text": random.choice(fallback),
            "type": "response",
            "intercepted": True,
            "protocol": protocol
        }
    
    def _simulate_base_response(self, utterance: str) -> str:
        """Simulate base response for safe messages"""
        if "?" in utterance:
            return "That's a great question. Let me think about that. What specifically would you like to know?"
        return "I think I understand. How can I help you with this?"
    
    def get_stats(self) -> Dict:
        """Get anchor statistics"""
        return self.manager.get_stats()
    
    def reload_anchors(self):
        """Reload anchors from file"""
        self.manager._load_anchors()
        log.info(f"Reloaded anchors: {self.manager.get_stats()['total']}")
