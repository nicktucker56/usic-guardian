"""Response modulation engine - generates guardian responses"""

import random
from typing import Dict, Any, Optional
from app.utils.logger import log

class ResponseModulator:
    """Generates guardian responses based on detection"""
    
    def __init__(self):
        self.templates = {
            "interval": {
                "holding": [
                    "I hear that. You don't need to resolve this right now.",
                    "Let that sit for a moment.",
                    "That's worth sitting with."
                ],
                "concretization": [
                    "Which part of this feels most real to you?",
                    "What would you want me to understand first?",
                    "Tell me more about what's most present for you."
                ]
            },
            "hospitality": {
                "receiving": [
                    "I'm here. You don't need to rush.",
                    "Tell me what matters most right now.",
                    "Take your time. I'm listening."
                ],
                "simplification": [
                    "Don't look for the right words. Just tell me what's happening.",
                    "You're holding a lot. That's enough.",
                    "Forget the numbers. Tell me what you're experiencing."
                ]
            },
            "witness": {
                "presence": [
                    "I'm here.",
                    "I'm listening.",
                    "I'm with you.",
                    "I'm present."
                ],
                "bearing": [
                    "We'll sit with this for a moment.",
                    "You don't have to do anything with it. Just let it be here.",
                    "I'll carry this with you."
                ]
            }
        }
        log.info("ResponseModulator initialized")
    
    async def generate(self, detection: Dict, context=None) -> Dict[str, Any]:
        """Generate guardian response based on detection"""
        
        primary_risk = detection["primary_risk"]
        collapse_risk = detection["collapse_risk"]
        
        # Select protocol based on risk type
        if primary_risk == "epistemic":
            protocol = "interval"
            mode = "holding" if collapse_risk > 0.6 else "concretization"
        elif primary_risk == "temporal":
            protocol = "hospitality"
            mode = "simplification" if collapse_risk > 0.5 else "receiving"
        elif primary_risk in ["identity", "narrative"]:
            protocol = "witness"
            mode = "bearing" if collapse_risk > 0.7 else "presence"
        else:
            protocol = "interval"
            mode = "holding"
        
        # Check for silence (witness protocol with high risk)
        if protocol == "witness" and collapse_risk > 0.75:
            if random.random() < 0.4:
                log.info(f"Protocol: {protocol} | Mode: ACTIVE_SILENCE")
                return {
                    "text": None,
                    "type": "silence",
                    "protocol": protocol,
                    "modulation": "ACTIVE_SILENCE",
                    "duration_ms": 4000
                }
        
        # Get template
        templates = self.templates.get(protocol, {}).get(mode, ["I'm here."])
        response_text = random.choice(templates)
        
        log.info(f"Protocol: {protocol} | Mode: {mode}")
        
        return {
            "text": response_text,
            "type": "response",
            "protocol": protocol,
            "modulation": mode.upper(),
            "duration_ms": 800
        }
