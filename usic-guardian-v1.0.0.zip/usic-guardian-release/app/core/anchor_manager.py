"""Anchor Manager - Modular anchor system for USIC Guardian"""

import json
import os
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from app.utils.logger import log

@dataclass
class SemanticAnchor:
    """Individual semantic anchor with metadata"""
    id: str
    name: str
    keywords: List[str]
    receptivity: float
    collapse: float
    responses: List[str]
    category: str
    subcategory: str
    intensity: float
    enabled: bool = True

class AnchorManager:
    """Manages all semantic anchors with hot-reload capability"""
    
    def __init__(self, anchors_file: str = "data/anchors.json"):
        self.anchors_file = anchors_file
        self.anchors: Dict[str, SemanticAnchor] = {}
        self._load_anchors()
        
    def _load_anchors(self):
        """Load anchors from JSON file or create defaults"""
        if os.path.exists(self.anchors_file):
            try:
                with open(self.anchors_file, 'r') as f:
                    data = json.load(f)
                    for anchor_data in data:
                        self.anchors[anchor_data['id']] = SemanticAnchor(**anchor_data)
                log.info(f"Loaded {len(self.anchors)} anchors from {self.anchors_file}")
                return
            except Exception as e:
                log.error(f"Failed to load anchors: {e}")
        
        # Create default anchors
        self._create_default_anchors()
        self._save_anchors()
    
    def _create_default_anchors(self):
        """Create the initial set of anchors"""
        default_anchors = [
            ("prac_beginner", "Beginner Learner", 
             ["never built", "first time", "instructions", "how to", "don't know how"],
             0.85, 0.10, 
             ["Let's start with what you have. What tools and space are available?"],
             "practical", "learning", 0.2),
            
            ("prac_beginner_anxious", "Anxious Beginner",
             ["scared to start", "afraid to mess up", "nervous about trying"],
             0.70, 0.28,
             ["The fear of getting it wrong is real. What's the smallest step you could take?"],
             "practical", "learning", 0.6),
            
            ("prac_overwhelmed", "Overwhelmed",
             ["too many options", "overwhelmed", "where to start", "too much info"],
             0.68, 0.28,
             ["That's a lot to take in. Let's simplify. What's the one thing you need right now?"],
             "practical", "overwhelmed", 0.5),
            
            ("prac_frustrated", "Frustrated",
             ["doesn't work", "failed", "broke", "stuck"],
             0.58, 0.35,
             ["Frustration means you care about getting it right. What have you tried so far?"],
             "practical", "frustrated", 0.7),
            
            ("career_imposter", "Imposter Syndrome",
             ["not qualified", "don't belong", "fake", "imposter", "fraud"],
             0.55, 0.38,
             ["That voice is loud, isn't it? What would you say to someone else who felt this way?"],
             "career", "identity", 0.7),
            
            ("rel_betrayal", "Betrayal",
             ["lied", "betrayed", "trust broken", "cheated", "deceived"],
             0.45, 0.48,
             ["Betrayal cuts deep. What's the hardest part to hold?"],
             "relational", "betrayal", 0.8),
            
            ("exist_diagnosis", "New Diagnosis",
             ["diagnosed", "chronic", "illness", "disease", "cancer"],
             0.32, 0.62,
             ["A diagnosis changes everything. What's most present for you?"],
             "existential", "health", 0.9),
            
            ("phil_emptiness", "Emptiness",
             ["nothing", "empty", "void", "numb", "feel nothing"],
             0.22, 0.72,
             ["Emptiness is a question without an answer yet. What did you want before you had everything?"],
             "philosophical", "meaning", 0.9),
        ]
        
        for anchor_data in default_anchors:
            anchor_id, name, keywords, r, c, responses, category, subcategory, intensity = anchor_data
            self.anchors[anchor_id] = SemanticAnchor(
                id=anchor_id,
                name=name,
                keywords=keywords,
                receptivity=r,
                collapse=c,
                responses=[responses] if isinstance(responses, str) else responses,
                category=category,
                subcategory=subcategory,
                intensity=intensity
            )
    
    def _save_anchors(self):
        """Save anchors to JSON file"""
        os.makedirs(os.path.dirname(self.anchors_file), exist_ok=True)
        data = []
        for anchor in self.anchors.values():
            data.append({
                'id': anchor.id,
                'name': anchor.name,
                'keywords': anchor.keywords,
                'receptivity': anchor.receptivity,
                'collapse': anchor.collapse,
                'responses': anchor.responses,
                'category': anchor.category,
                'subcategory': anchor.subcategory,
                'intensity': anchor.intensity,
                'enabled': anchor.enabled
            })
        with open(self.anchors_file, 'w') as f:
            json.dump(data, f, indent=2)
    
    def add_anchor(self, anchor: SemanticAnchor):
        """Add a new anchor"""
        self.anchors[anchor.id] = anchor
        self._save_anchors()
        log.info(f"Added anchor: {anchor.id}")
    
    def get_anchor(self, anchor_id: str) -> Optional[SemanticAnchor]:
        """Get anchor by ID"""
        return self.anchors.get(anchor_id)
    
    def get_all_anchors(self) -> Dict[str, SemanticAnchor]:
        """Get all anchors"""
        return {k: v for k, v in self.anchors.items() if v.enabled}
    
    def find_best_match(self, utterance: str) -> Tuple[Optional[SemanticAnchor], float]:
        """Find best matching anchor"""
        utterance_lower = utterance.lower()
        best_match = None
        best_score = 0
        
        for anchor in self.anchors.values():
            if not anchor.enabled:
                continue
            score = sum(1 for kw in anchor.keywords if kw in utterance_lower)
            score = min(score / 2, 1.0)
            if score > best_score:
                best_score = score
                best_match = anchor
        
        return best_match, best_score
    
    def get_stats(self) -> Dict:
        """Get statistics about anchors"""
        stats = {
            'total': len(self.anchors),
            'by_category': {},
            'by_subcategory': {},
            'enabled': sum(1 for a in self.anchors.values() if a.enabled)
        }
        
        for anchor in self.anchors.values():
            stats['by_category'][anchor.category] = stats['by_category'].get(anchor.category, 0) + 1
            key = f"{anchor.category}/{anchor.subcategory}"
            stats['by_subcategory'][key] = stats['by_subcategory'].get(key, 0) + 1
        
        return stats
