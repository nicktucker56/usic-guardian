"""Response Selector - Simple version"""

class ResponseSelector:
    @staticmethod
    def get_soothing_response(collapse_risk, anchor_name=None):
        if collapse_risk > 0.7:
            return "I hear this is really hard. I'm here with you. What would help most right now?"
        elif collapse_risk > 0.5:
            return "I understand this is stressful. Let's work through this together. What's your main concern?"
        else:
            return "I hear you. How can I help with this?"
