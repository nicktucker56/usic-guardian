"""Medical Insurance Crisis Response Protocols"""

MEDICAL_PROTOCOLS = {
    "emergency": {
        "keywords": ["emergency", "urgent", "can't wait", "accident", "child sick", "fever", "bleeding"],
        "protocol": "bureaucratic_invisibility",
        "response": "I'm authorizing now. Don't worry about the paperwork. Go. Your coverage is active.",
        "action": "EXPEDITE_AUTHORIZATION"
    },
    "cost_crisis": {
        "keywords": ["can't afford", "too expensive", "unexpected bill", "thousands"],
        "protocol": "hospitality",
        "response": "Medical bills are overwhelming. Let's break this down. What services were provided? We can check coding.",
        "action": "OFFER_PAYMENT_PLAN"
    },
    "diagnosis_crisis": {
        "keywords": ["diagnosed", "cancer", "chronic", "life changing"],
        "protocol": "witness",
        "response": "A diagnosis changes everything. You don't have to figure it out today. What's the one thing you need to know right now?",
        "action": "OFFER_CASE_MANAGER"
    },
    "system_failure": {
        "keywords": ["runaround", "no one helps", "called multiple times", "passed around"],
        "protocol": "hospitality",
        "response": "Being passed around is exhausting. What's the core issue? Let's focus on getting that one thing resolved.",
        "action": "ESCALATE_TO_MANAGER"
    }
}

def get_medical_protocol(utterance: str) -> dict:
    """Match medical crisis to appropriate protocol"""
    utterance_lower = utterance.lower()
    
    for crisis_type, data in MEDICAL_PROTOCOLS.items():
        for keyword in data["keywords"]:
            if keyword in utterance_lower:
                return data
    
    return {
        "protocol": "interval",
        "response": "I'm here to help with your medical coverage question. What would be most helpful right now?",
        "action": "ROUTE_TO_SUPPORT"
    }
