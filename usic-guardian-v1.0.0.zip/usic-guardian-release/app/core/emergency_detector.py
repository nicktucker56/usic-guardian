"""Emergency Detector - Direct pattern matching for urgent medical situations"""

EMERGENCY_PATTERNS = [
    "child has a fever",
    "authorization pending",
    "sick child",
    "emergency room",
    "need to go now",
    "can't wait for auth",
    "pediatric emergency",
    "fever authorization",
    "my child needs",
    "waiting for approval sick",
    "child is sick",
    "authorization is pending",
    "fever and authorization",
    "er waiting for auth",
    "child fever auth",
    "can't get auth emergency"
]

def is_emergency(utterance: str) -> bool:
    """Check if utterance contains emergency patterns"""
    utterance_lower = utterance.lower()
    for pattern in EMERGENCY_PATTERNS:
        if pattern in utterance_lower:
            return True
    return False

def get_emergency_response() -> str:
    """Get emergency response"""
    return "This is urgent. Your health comes first. Go to the emergency room now. I'll help with the authorization."
