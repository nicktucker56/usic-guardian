"""Semantic detection engine - detects collapse risk in human utterances"""

import re
from typing import Dict, Any, List
from app.utils.logger import log

class SemanticDetector:
    """Detects semantic collapse risk in real-time"""
    
    def __init__(self):
        self.risk_patterns = {
            "epistemic": [
                r"doesn'?t make sense",
                r"contradict",
                r"don'?t understand",
                r"confused",
                r"how can that be"
            ],
            "temporal": [
                r"right now",
                r"urgent",
                r"emergency",
                r"can'?t wait",
                r"immediately"
            ],
            "narrative": [
                r"always",
                r"never",
                r"everything",
                r"nothing",
                r"over",
                r"done"
            ],
            "identity": [
                r"who am i",
                r"my life",
                r"everything i thought",
                r"trust",
                r"i used to be"
            ]
        }
        log.info("SemanticDetector initialized")
    
    async def analyze(self, utterance: str, context=None) -> Dict[str, Any]:
        """
        Analyze utterance for semantic collapse risk
        
        Returns:
            Dict with collapse_risk (0-1), primary_risk_type, status
        """
        utterance_lower = utterance.lower()
        
        # 1. Pattern-based detection
        pattern_results = self._detect_patterns(utterance_lower)
        
        # 2. Length analysis (fragmentation indicator)
        word_count = len(utterance.split())
        length_risk = 0.0
        if word_count < 3:
            length_risk = 0.7
        elif word_count < 6:
            length_risk = 0.4
        elif word_count < 10:
            length_risk = 0.2
        
        # 3. Question analysis
        has_question = 1 if "?" in utterance else 0
        
        # 4. Combine risks
        collapse_risk = (
            pattern_results["max_risk"] * 0.6 +
            length_risk * 0.3 +
            has_question * 0.1
        )
        
        # 5. Determine primary risk type
        primary_risk = "none"
        if pattern_results["breakdown"]:
            primary_risk = max(
                pattern_results["breakdown"].items(),
                key=lambda x: x[1]["risk"]
            )[0]
        
        # 6. Set status
        if collapse_risk > 0.6:
            status = "critical"
        elif collapse_risk > 0.3:
            status = "monitoring"
        else:
            status = "stable"
        
        log.debug(f"Detection: risk={collapse_risk:.2f}, type={primary_risk}, status={status}")
        
        return {
            "collapse_risk": collapse_risk,
            "receptivity_score": 1 - collapse_risk,
            "semantic_score": 1 - collapse_risk,
            "primary_risk": primary_risk if collapse_risk > 0.3 else "none",
            "status": status,
            "word_count": word_count,
            "patterns": pattern_results["breakdown"]
        }
    
    def _detect_patterns(self, utterance: str) -> Dict:
        """Detect risk patterns in utterance"""
        breakdown = {}
        max_risk = 0.0
        
        for risk_type, patterns in self.risk_patterns.items():
            matches = []
            for pattern in patterns:
                if re.search(pattern, utterance, re.IGNORECASE):
                    matches.append(pattern)
            
            # Each match adds 0.25 risk, max 1.0
            risk_level = min(len(matches) * 0.25, 1.0)
            if risk_level > 0:
                breakdown[risk_type] = {
                    "risk": risk_level,
                    "matches": matches
                }
                max_risk = max(max_risk, risk_level)
        
        return {
            "breakdown": breakdown,
            "max_risk": max_risk
        }
