"""Contextual Semantic Analyzer - Distinguishes between literal and metaphorical meaning"""

import re
from typing import Dict, List, Tuple, Optional
from app.utils.logger import log

class ContextAnalyzer:
    """Analyzes the context of utterances to determine semantic meaning"""
    
    def __init__(self):
        # Context markers that indicate metaphorical/literal usage
        self.metaphorical_markers = {
            "life": ["my life", "your life", "his life", "her life", "our life", "their life"],
            "self": ["myself", "yourself", "himself", "herself", "myself", "i feel", "i am"],
            "feeling": ["feel", "feeling", "felt", "emotion", "empty inside"],
            "existential": ["everything", "nothing", "point", "purpose", "meaning"],
            "identity": ["who am i", "what am i", "become", "turning into"],
            "time": ["these days", "lately", "recently", "always", "never"],
            "relationship": ["relationship", "marriage", "friendship", "love"],
            "work": ["career", "job", "work", "profession", "calling"],
        }
        
        self.literal_markers = {
            "container": ["bottle", "glass", "cup", "container", "box", "bag", "tank", "jug", "jar"],
            "storage": ["fridge", "cabinet", "shelf", "pantry", "garage", "closet", "drawer"],
            "object": ["it's", "that is", "this is", "looks", "seems"],
            "measurement": ["liters", "gallons", "ounces", "ml", "cups", "teaspoons"],
            "action": ["pour", "fill", "drink", "use", "need", "get"],
            "question_prefix": ["is the", "is this", "is that", "does the", "does this"],
        }
        
        # Contextual weightings
        self.context_weights = {
            "metaphorical": 0.7,
            "literal": 0.3,
            "neutral": 0.5
        }
    
    def analyze(self, utterance: str) -> Dict:
        """
        Analyze utterance context and return:
        - context_type: "metaphorical", "literal", or "mixed"
        - confidence: 0-1 score
        - key_context: the primary contextual clue
        - adjusted_receptivity: modified based on context
        - adjusted_collapse: modified based on context
        """
        utterance_lower = utterance.lower()
        
        # Check for metaphorical markers
        metaphorical_score = 0
        metaphorical_matches = []
        for category, markers in self.metaphorical_markers.items():
            for marker in markers:
                if marker in utterance_lower:
                    metaphorical_score += 1
                    metaphorical_matches.append(f"{category}:{marker}")
        
        # Check for literal markers
        literal_score = 0
        literal_matches = []
        for category, markers in self.literal_markers.items():
            for marker in markers:
                if marker in utterance_lower:
                    literal_score += 1
                    literal_matches.append(f"{category}:{marker}")
        
        # Normalize scores
        max_score = max(metaphorical_score, literal_score, 1)
        metaphorical_weight = min(metaphorical_score / max_score, 1.0)
        literal_weight = min(literal_score / max_score, 1.0)
        
        # Determine context type
        if metaphorical_weight > 0.6 and literal_weight < 0.3:
            context_type = "metaphorical"
            confidence = metaphorical_weight
            adjustment = {"receptivity": -0.15, "collapse": +0.20}
            explanation = f"Metaphorical language detected: {', '.join(metaphorical_matches[:3])}"
        elif literal_weight > 0.6 and metaphorical_weight < 0.3:
            context_type = "literal"
            confidence = literal_weight
            adjustment = {"receptivity": +0.10, "collapse": -0.15}
            explanation = f"Literal context detected: {', '.join(literal_matches[:3])}"
        elif metaphorical_weight > 0.3 and literal_weight > 0.3:
            context_type = "mixed"
            confidence = max(metaphorical_weight, literal_weight)
            adjustment = {"receptivity": -0.05, "collapse": +0.05}
            explanation = "Mixed context - requires careful interpretation"
        else:
            context_type = "neutral"
            confidence = 0.5
            adjustment = {"receptivity": 0, "collapse": 0}
            explanation = "No strong contextual markers"
        
        return {
            "context_type": context_type,
            "confidence": confidence,
            "metaphorical_score": metaphorical_weight,
            "literal_score": literal_weight,
            "adjustment": adjustment,
            "explanation": explanation,
            "metaphorical_matches": metaphorical_matches[:5],
            "literal_matches": literal_matches[:5]
        }
    
    def adjust_semantic_state(self, state: Dict, context: Dict) -> Dict:
        """Adjust semantic state based on context analysis"""
        adjustment = context["adjustment"]
        
        # Apply adjustments
        new_receptivity = state["receptivity"] + adjustment["receptivity"]
        new_collapse = state["collapse_risk"] + adjustment["collapse"]
        
        # Clamp values
        new_receptivity = max(0.0, min(1.0, new_receptivity))
        new_collapse = max(0.0, min(1.0, new_collapse))
        
        # Recalculate trajectory
        if new_collapse > 0.65:
            trajectory = "collapsing"
        elif new_collapse > 0.45:
            trajectory = "fragmenting"
        else:
            trajectory = "stable"
        
        return {
            **state,
            "receptivity": new_receptivity,
            "collapse_risk": new_collapse,
            "semantic_score": 1 - new_collapse,
            "trajectory": trajectory,
            "context_type": context["context_type"],
            "context_confidence": context["confidence"],
            "context_explanation": context["explanation"]
        }
    
    def should_override_anchor(self, utterance: str, anchor: any) -> Tuple[bool, str]:
        """Determine if anchor should be overridden due to context"""
        context = self.analyze(utterance)
        
        # If literal context overrides a high-risk anchor
        if context["context_type"] == "literal" and anchor and anchor.collapse > 0.6:
            return True, "literal_context"
        
        # If metaphorical context overrides a low-risk anchor
        if context["context_type"] == "metaphorical" and anchor and anchor.collapse < 0.3:
            return True, "metaphorical_context"
        
        return False, None
