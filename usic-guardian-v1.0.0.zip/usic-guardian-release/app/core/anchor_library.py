"""Expanded Semantic Anchor Library - 100+ anchors"""

from typing import Dict, List, Optional, Tuple

class AnchorLibrary:
    """Complete library with 100+ anchors across all categories"""
    
    def __init__(self):
        self.anchors = self._build_anchors()
        print(f"✅ Loaded {len(self.anchors)} anchors")
    
    def _build_anchors(self) -> Dict:
        """Build all 100+ anchors"""
        anchors = {}
        
        # === PRACTICAL (15 anchors) ===
        practical = [
            ("prac_beginner", ["never built", "first time", "instructions", "how to", "don't know how"], 0.85, 0.10,
             ["Let's start with what you have. What tools and space are available?"]),
            ("prac_beginner_anxious", ["scared to start", "afraid to mess up", "nervous about trying"], 0.70, 0.28,
             ["The fear of getting it wrong is real. What's the smallest step you could take?"]),
            ("prac_beginner_unsure", ["not sure how", "unsure where to start", "confused about process"], 0.75, 0.22,
             ["Not knowing is the first step to knowing. What part is most confusing?"]),
            ("prac_overwhelmed", ["too many options", "overwhelmed", "where to start", "too much info"], 0.68, 0.28,
             ["That's a lot to take in. Let's simplify. What's the one thing you need right now?"]),
            ("prac_frustrated", ["doesn't work", "failed", "broke", "stuck", "can't figure out"], 0.58, 0.35,
             ["Frustration is real. What part is giving you trouble?"]),
            ("prac_resource_limited", ["limited tools", "no equipment", "only have", "can't afford"], 0.75, 0.18,
             ["Working with what you have is honest. Let's work within your constraints."]),
            ("prac_resource_time", ["no time", "busy", "rushed", "short on time"], 0.65, 0.28,
             ["Time pressure adds weight. What's the most important thing to accomplish?"]),
            ("prac_resource_budget", ["expensive", "cost too much", "can't afford", "tight budget"], 0.70, 0.22,
             ["Let's work with your budget. What's the range you're comfortable with?"]),
            ("prac_skill_learning", ["not skilled", "never done", "beginner", "learning"], 0.80, 0.15,
             ["Everyone starts somewhere. What feels like the biggest gap right now?"]),
            ("prac_mistake", ["made a mistake", "error", "wrong", "messed up"], 0.55, 0.35,
             ["Mistakes are how we learn. What would you do differently next time?"]),
            ("prac_repair", ["fix", "repair", "broken", "not working"], 0.65, 0.28,
             ["Fixing things takes patience. What have you tried already?"]),
            ("prac_improve", ["improve", "better", "upgrade", "enhance"], 0.78, 0.16,
             ["Wanting to improve is a good instinct. What's your goal?"]),
            ("prac_decision", ["decide", "choose", "pick", "which one"], 0.72, 0.20,
             ["Decisions can be hard. What's your gut telling you?"]),
            ("prac_confused", ["confused", "don't understand", "what does this mean"], 0.68, 0.25,
             ["Confusion is part of learning. What's the part that's unclear?"]),
            ("prac_excited", ["excited", "can't wait", "looking forward"], 0.90, 0.05,
             ["Excitement is wonderful! What are you most looking forward to?"]),
        ]
        
        # === CAREER (20 anchors) ===
        career = [
            ("career_anxiety", ["interview", "laid off", "job search", "haven't interviewed", "decades"], 0.65, 0.28,
             ["That gap of time can feel enormous. What feels most unfamiliar now?"]),
            ("career_imposter", ["not qualified", "don't belong", "fake", "imposter", "fraud"], 0.55, 0.38,
             ["That voice is loud, isn't it? What would you say to someone else who felt this way?"]),
            ("career_rejection", ["rejected", "didn't get", "not chosen", "failed interview"], 0.50, 0.42,
             ["Rejection hits hard. What's coming up for you?"]),
            ("career_burnout", ["burnout", "exhausted", "no energy", "drained", "tired all the time"], 0.44, 0.50,
             ["Burnout is real. What's the smallest thing that would give you relief?"]),
            ("career_stuck", ["stuck", "no progress", "dead end", "can't move"], 0.52, 0.40,
             ["Feeling stuck is heavy. What would feel like forward motion?"]),
            ("career_meaning", ["meaning", "purpose", "why am I doing this", "pointless"], 0.48, 0.45,
             ["Purpose questions are hard. What drew you to this work originally?"]),
            ("career_change", ["career change", "new field", "starting over", "different path"], 0.62, 0.30,
             ["Starting over takes courage. What's calling you?"]),
            ("career_promotion", ["promotion", "advance", "move up", "next level"], 0.70, 0.22,
             ["Growth is good. What's your sense of what's needed?"]),
            ("career_conflict", ["boss", "manager", "colleague", "work conflict"], 0.58, 0.34,
             ["Workplace conflict is draining. What would you want to shift?"]),
            ("career_salary", ["salary", "pay", "raise", "underpaid"], 0.60, 0.32,
             ["Money conversations are tough. What's fair feel like to you?"]),
            ("career_balance", ["work-life", "balance", "family time", "no time"], 0.55, 0.38,
             ["Balance is hard. What would make the biggest difference?"]),
            ("career_future", ["future", "what's next", "where am I going", "direction"], 0.50, 0.42,
             ["The future is uncertain. What do you want to be true in 5 years?"]),
            ("career_new_role", ["new job", "just started", "don't know what I'm doing"], 0.58, 0.35,
             ["Being new is hard. What's one thing you've already learned?"]),
            ("career_remote", ["remote", "work from home", "virtual", "zoom"], 0.62, 0.30,
             ["Remote work changes everything. What's working and what's not?"]),
            ("career_return", ["returning to work", "career break", "been away"], 0.60, 0.32,
             ["Coming back after time away takes courage. What's most different now?"]),
            ("career_laid_off", ["laid off", "fired", "let go", "terminated"], 0.48, 0.45,
             ["Losing a job is a loss. What's the hardest part right now?"]),
            ("career_negotiation", ["negotiate", "offer", "counter offer", "asking for more"], 0.65, 0.28,
             ["Negotiation takes courage. What's your ideal outcome?"]),
            ("career_mentor", ["mentor", "guidance", "advice", "someone to guide"], 0.70, 0.22,
             ["Having guidance helps. What kind of support would be most valuable?"]),
            ("career_skills", ["skills", "upskill", "learn new", "training"], 0.75, 0.18,
             ["Learning new skills is empowering. What's exciting about this?"]),
            ("career_success", ["success", "achievement", "accomplished", "proud"], 0.85, 0.10,
             ["Success is meaningful. What are you most proud of?"]),
        ]
        
        # === RELATIONAL (25 anchors) ===
        relational = [
            ("rel_betrayal", ["lied", "betrayed", "trust broken", "cheated", "deceived"], 0.45, 0.48,
             ["Betrayal cuts deep. What's the hardest part to hold?"]),
            ("rel_conflict", ["argument", "fight", "angry", "can't communicate"], 0.48, 0.45,
             ["Conflict is heavy. What's underneath the anger?"]),
            ("rel_loss", ["lost friend", "ended", "cut off", "estranged"], 0.42, 0.52,
             ["Loss of connection is a unique grief. What do you miss most?"]),
            ("rel_parent", ["parent", "mother", "father", "family issues"], 0.50, 0.44,
             ["Family is complicated. What's the hardest part to navigate?"]),
            ("rel_child", ["child", "kids", "son", "daughter", "parenting"], 0.55, 0.38,
             ["Parenting is hard. What's weighing on you?"]),
            ("rel_partner", ["partner", "spouse", "husband", "wife", "relationship"], 0.52, 0.42,
             ["Relationships take work. What's present for you?"]),
            ("rel_divorce", ["divorce", "separated", "split", "leaving"], 0.38, 0.55,
             ["Separation is profound. What do you need right now?"]),
            ("rel_jealousy", ["jealous", "envy", "compare", "not good enough"], 0.48, 0.46,
             ["Comparison is painful. What's the story you're telling yourself?"]),
            ("rel_boundaries", ["boundaries", "too much", "drained", "can't say no"], 0.52, 0.42,
             ["Boundaries are self-respect. What would you want to protect?"]),
            ("rel_apology", ["apologize", "sorry", "wrong", "forgive"], 0.58, 0.35,
             ["Apologizing is vulnerable. What would you want to be understood?"]),
            ("rel_forgiveness", ["forgive", "let go", "resentment", "holding on"], 0.50, 0.44,
             ["Forgiveness is a process. What's getting in the way?"]),
            ("rel_loneliness", ["alone", "lonely", "isolated", "no one"], 0.42, 0.50,
             ["Loneliness is heavy. What would connection feel like?"]),
            ("rel_belonging", ["community", "belong", "tribe", "fit in"], 0.55, 0.38,
             ["Belonging matters. What kind of connection are you looking for?"]),
            ("rel_dependency", ["need them", "can't live without", "codependent"], 0.44, 0.49,
             ["Dependency is tender. What do you need to feel whole on your own?"]),
            ("rel_friendship", ["friend", "friendship", "close friend", "best friend"], 0.60, 0.32,
             ["Friendship is precious. What's on your heart about this?"]),
            ("rel_sibling", ["brother", "sister", "sibling"], 0.52, 0.42,
             ["Sibling relationships run deep. What's present for you?"]),
            ("rel_communication", ["communicate", "express", "say what I mean"], 0.58, 0.36,
             ["Communication is hard. What gets lost in translation?"]),
            ("rel_trust", ["trust", "don't trust", "can't trust"], 0.48, 0.46,
             ["Trust is fragile. What would need to happen to rebuild it?"]),
            ("rel_abandonment", ["abandoned", "left", "walked away"], 0.40, 0.52,
             ["Abandonment wounds are deep. What does that bring up for you?"]),
            ("rel_reconciliation", ["reconcile", "make up", "repair"], 0.55, 0.38,
             ["Repair takes courage. What would you want to be different?"]),
            ("rel_in_love", ["in love", "falling", "new relationship"], 0.85, 0.10,
             ["Love is beautiful. What's exciting about this connection?"]),
            ("rel_heartbreak", ["heartbreak", "broken heart", "devastated"], 0.35, 0.58,
             ["Heartbreak is real. What do you need to heal?"]),
            ("rel_family_estrangement", ["estranged", "no contact", "cut off family"], 0.40, 0.52,
             ["Family estrangement is complex. What do you need to protect?"]),
            ("rel_caregiving", ["caregiving", "taking care", "caring for"], 0.48, 0.45,
             ["Caregiving is love and exhaustion. Who's holding you?"]),
            ("rel_grief", ["grief", "mourning", "loss of loved one"], 0.35, 0.58,
             ["Grief has no timeline. What's present for you today?"]),
        ]
        
        # === EXISTENTIAL (20 anchors) ===
        existential = [
            ("exist_diagnosis", ["diagnosed", "chronic", "illness", "disease", "cancer"], 0.32, 0.62,
             ["A diagnosis changes everything. What's most present for you?"]),
            ("exist_mortality", ["dying", "death", "limited time", "terminal"], 0.25, 0.68,
             ["That's the hardest conversation. What do you need to say?"]),
            ("exist_caregiver", ["caring for", "parent sick", "burnout", "no support"], 0.35, 0.58,
             ["Caregiving while grieving is lonely. Who's holding you?"]),
            ("exist_grief", ["grief", "died", "passed", "gone"], 0.30, 0.65,
             ["Grief is love with nowhere to go. What do you miss most?"]),
            ("exist_identity", ["who am I", "lost myself", "no identity", "don't know myself"], 0.28, 0.66,
             ["Losing your sense of self is disorienting. What did you used to know?"]),
            ("exist_aging", ["aging", "old", "getting older", "time passing"], 0.40, 0.52,
             ["Aging brings reflection. What's the hardest part to face?"]),
            ("exist_legacy", ["legacy", "leave behind", "matter", "remembered"], 0.38, 0.54,
             ["Wanting to matter is human. What would you want to leave?"]),
            ("exist_regret", ["regret", "should have", "if only", "wish I had"], 0.35, 0.58,
             ["Regret is heavy. What would you tell your younger self?"]),
            ("exist_freedom", ["trapped", "no choice", "have to", "must"], 0.33, 0.60,
             ["Feeling trapped is suffocating. What would choice feel like?"]),
            ("exist_uncertainty", ["don't know", "uncertain", "no answers", "confused"], 0.42, 0.52,
             ["Uncertainty is uncomfortable. What would clarity feel like?"]),
            ("exist_meaning", ["meaning", "purpose", "why am I here", "point"], 0.28, 0.66,
             ["That question can't be answered—it has to be lived."]),
            ("exist_surrender", ["give up", "surrender", "let go", "release"], 0.22, 0.72,
             ["Surrender isn't giving up. It's letting go of what you can't control."]),
            ("exist_fear", ["fear", "scared", "terrified", "afraid"], 0.38, 0.55,
             ["Fear is a compass. What's underneath it?"]),
            ("exist_hopeless", ["hopeless", "no hope", "nothing will change"], 0.18, 0.78,
             ["That weight is real. You don't have to carry it alone."]),
            ("exist_aloneness", ["alone", "no one understands", "nobody gets it"], 0.35, 0.58,
             ["Feeling alone in your experience is hard. I'm here."]),
            ("exist_transformation", ["changing", "becoming", "different person"], 0.45, 0.48,
             ["Transformation is uncomfortable. What's emerging?"]),
            ("exist_crisis", ["crisis", "breaking point", "can't take it"], 0.20, 0.75,
             ["Crisis is overwhelming. Let's focus on what you need right now."]),
            ("exist_resilience", ["survive", "get through", "strong"], 0.65, 0.28,
             ["Strength in hard times is real. What's carried you this far?"]),
            ("exist_vulnerability", ["vulnerable", "exposed", "raw"], 0.48, 0.45,
             ["Vulnerability takes courage. What's asking to be seen?"]),
            ("exist_integration", ["integrate", "whole", "bring together"], 0.55, 0.38,
             ["Integration takes time. What's trying to come together?"]),
        ]
        
        # === PHILOSOPHICAL (20 anchors) ===
        philosophical = [
            ("phil_emptiness", ["nothing", "empty", "void", "numb", "feel nothing"], 0.22, 0.72,
             ["Emptiness is a question without an answer yet. What did you want before you had everything?"]),
            ("phil_despair", ["hopeless", "no future", "can't go on", "despair"], 0.12, 0.85,
             ["That weight is real. You don't have to carry it alone."]),
            ("phil_meaning", ["point", "purpose", "why bother", "meaningless"], 0.18, 0.78,
             ["Meaning isn't found—it's made. What matters enough to carry without certainty?"]),
            ("phil_nihilism", ["nothing matters", "no meaning", "why anything"], 0.15, 0.82,
             ["Nihilism is heavy. What would make it matter, even temporarily?"]),
            ("phil_hope", ["hope", "maybe", "could be", "possible"], 0.68, 0.25,
             ["Hope is precious. What's giving you that sense?"]),
            ("phil_transcendence", ["beyond", "more than", "greater", "spiritual"], 0.45, 0.48,
             ["Seeking something greater is human. What's calling you?"]),
            ("phil_wisdom", ["wise", "older", "learned", "experienced"], 0.58, 0.35,
             ["Wisdom comes from living. What have you learned?"]),
            ("phil_gratitude", ["grateful", "thankful", "blessed", "appreciate"], 0.85, 0.10,
             ["Gratitude is grounding. What are you noticing?"]),
            ("phil_suffering", ["suffering", "pain", "hard", "difficult"], 0.30, 0.62,
             ["Suffering is part of being human. What's asking to be seen?"]),
            ("phil_acceptance", ["accept", "okay", "it is what it is", "let be"], 0.50, 0.42,
             ["Acceptance is active. What are you learning to hold?"]),
            ("phil_truth", ["truth", "real", "honest", "what's true"], 0.60, 0.32,
             ["Truth can be hard. What's asking to be spoken?"]),
            ("phil_illusion", ["illusion", "pretend", "fake", "not real"], 0.48, 0.45,
             ["Letting go of illusion is painful. What feels more real now?"]),
            ("phil_wonder", ["wonder", "awe", "amazing", "beautiful"], 0.85, 0.10,
             ["Wonder is precious. What's catching your attention?"]),
            ("phil_mystery", ["mystery", "unknown", "can't explain"], 0.55, 0.38,
             ["Mystery invites us to be humble. What's beyond understanding?"]),
            ("phil_integration", ["integrate", "whole", "bring together", "unify"], 0.60, 0.32,
             ["Integration takes time. What's trying to come together?"]),
            ("phil_paradox", ["paradox", "contradiction", "both/and"], 0.58, 0.35,
             ["Paradox holds truth. What feels like both at once?"]),
            ("phil_impermanence", ["impermanent", "temporary", "passing", "change"], 0.52, 0.42,
             ["Impermanence is both freeing and hard. What's shifting for you?"]),
            ("phil_connection", ["connected", "interconnected", "one with"], 0.70, 0.22,
             ["Connection is profound. What are you feeling connected to?"]),
            ("phil_awakening", ["awakening", "realization", "sudden understanding"], 0.65, 0.28,
             ["Awakening moments shift things. What's becoming clearer?"]),
            ("phil_silence", ["silence", "quiet", "stillness"], 0.72, 0.20,
             ["Silence holds wisdom. What's present in the quiet?"]),
        ]
        
        # Add all anchors
        for anchor in practical + career + relational + existential + philosophical:
            anchor_id, keywords, r, c, responses = anchor
            anchors[anchor_id] = {
                "id": anchor_id,
                "keywords": keywords,
                "r": r,
                "c": c,
                "responses": responses
            }
        
        return anchors
    
    def get(self, anchor_id: str) -> Optional[Dict]:
        """Get anchor by ID"""
        return self.anchors.get(anchor_id)
    
    def find_best_match(self, utterance: str) -> Tuple[Optional[Dict], float]:
        """Find best matching anchor"""
        utterance_lower = utterance.lower()
        best_match = None
        best_score = 0
        
        for anchor_id, anchor in self.anchors.items():
            score = sum(1 for kw in anchor["keywords"] if kw in utterance_lower)
            score = min(score / 2, 1.0)
            if score > best_score:
                best_score = score
                best_match = anchor
        
        return best_match, best_score
    
    def count(self) -> int:
        return len(self.anchors)
