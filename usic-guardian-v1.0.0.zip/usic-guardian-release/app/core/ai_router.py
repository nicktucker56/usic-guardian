"""AI Model Router - DeepSeek"""

import httpx
from typing import Optional, Dict, Any
from app.utils.logger import log
from app.utils.config import settings

class AIRouter:
    def __init__(self):
        self.client = httpx.Client(timeout=30.0)
        
        # Check for DeepSeek key
        if settings.deepseek_api_key and settings.deepseek_api_key not in ["", "your_deepseek_key_here", None]:
            self.active_model = "deepseek"
            log.info("✅ DeepSeek API ready")
        else:
            self.active_model = "simulated"
            log.warning("❌ No valid API key")
    
    async def generate(self, prompt: str, context: Dict = None, session_id: str = None) -> str:
        """Generate response using AI"""
        
        if self.active_model == "deepseek":
            response = await self._call_deepseek(prompt)
            if response:
                return response
        
        return self._get_fallback_response(prompt)
    
    async def _call_deepseek(self, prompt: str) -> Optional[str]:
        try:
            response = self.client.post(
                "https://api.deepseek.com/v1/chat/completions",
                headers={
                    "Authorization": f"Bearer {settings.deepseek_api_key}",
                    "Content-Type": "application/json"
                },
                json={
                    "model": "deepseek-chat",
                    "messages": [{"role": "user", "content": prompt}],
                    "max_tokens": 300,
                    "temperature": 0.7
                },
                timeout=15
            )
            
            if response.status_code != 200:
                log.error(f"DeepSeek error {response.status_code}")
                return None
            
            result = response.json()
            return result["choices"][0]["message"]["content"]
            
        except Exception as e:
            log.error(f"DeepSeek exception: {e}")
            return None
    
    def _get_fallback_response(self, prompt: str) -> str:
        if "?" in prompt:
            return "That's a thoughtful question. What's your sense of it?"
        return "I appreciate you sharing that. Tell me more."
